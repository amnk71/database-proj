document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const address = document.getElementById('address').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const messageElement = document.getElementById('message');

    if (password !== confirmPassword) {
        messageElement.textContent = '❌ Passwords do not match.';
        messageElement.style.color = 'red';
        return;
    }

    fetch('http://localhost:5000/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, address, phone, email, password })
    })
    .then(response => response.json())
    .then(result => {
        messageElement.textContent = result.message || result.error;
        messageElement.style.color = result.error ? 'red' : 'green';
    })
    .catch(error => {
        console.error('Error:', error);
        messageElement.textContent = '❌ Could not connect to server.';
        messageElement.style.color = 'red';
    });
});

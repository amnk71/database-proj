document.getElementById('loginForm').addEventListener('submit', async function (e) {
    e.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const messageElement = document.getElementById('message');
  
    try {
      const response = await fetch('http://127.0.0.1:5000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include', // Send session cookie
        body: JSON.stringify({ email, password })
      });
  
      const result = await response.json();
      messageElement.textContent = result.message || result.error;
      messageElement.style.color = result.error ? 'red' : 'green';
  
      if (response.ok) {
        setTimeout(() => {
          // ✅ Redirect to new restaurants dashboard
          window.location.href = '/frontend/pages/restaurants.html';
        }, 1000);
      }
  
    } catch (error) {
      messageElement.textContent = '❌ Could not connect to server.';
      messageElement.style.color = 'red';
      console.error(error);
    }
  });
  
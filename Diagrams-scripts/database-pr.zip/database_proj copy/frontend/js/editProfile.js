// Load user data on page load
window.addEventListener("DOMContentLoaded", async () => {
    try {
      const res = await fetch("http://127.0.0.1:5000/get-user", {
        method: "GET",
        credentials: "include" // use session
      });
  
      const data = await res.json();
  
      if (data.user) {
        document.getElementById("name").value = data.user.name;
        document.getElementById("address").value = data.user.address;
        document.getElementById("phone").value = data.user.phone;
        document.getElementById("email").value = data.user.email;
      } else {
        alert("⚠️ Could not load user info. Please login again.");
        window.location.href = "/frontend/pages/login.html";
      }
    } catch (err) {
      console.error("❌ Error loading user data:", err);
    }
  });
  
  // Handle form submission
  document.getElementById("editForm").addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const updatedUser = {
      name: document.getElementById("name").value,
      address: document.getElementById("address").value,
      phone: document.getElementById("phone").value
      // email is not sent — backend uses session
    };
  
    try {
      const res = await fetch("http://127.0.0.1:5000/update-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(updatedUser)
      });
  
      const result = await res.json();
      alert(result.message || result.error);
  
      if (result.message) {
        window.location.href = "/frontend/pages/dashboard.html";
      }
  
    } catch (error) {
      alert("❌ Could not update profile.");
      console.error(error);
    }
  });
  
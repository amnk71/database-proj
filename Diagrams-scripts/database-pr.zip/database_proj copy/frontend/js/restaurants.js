const restaurants = [
    { name: "Sakura Sushi", cuisine: "Japanese", address: "123 Tokyo St" },
    { name: "Bella Italia", cuisine: "Italian", address: "456 Rome Ave" },
    { name: "Spice Route", cuisine: "Indian", address: "789 Delhi Blvd" },
    { name: "Tacos El Mexicano", cuisine: "Mexican", address: "321 Mexico City Rd" },
    { name: "Burger House", cuisine: "American", address: "654 NYC Lane" },
    { name: "Green Garden", cuisine: "Vegetarian", address: "888 Fresh Way" },
    { name: "Dragon Wok", cuisine: "Chinese", address: "222 Beijing Rd" },
    { name: "Le Gourmet", cuisine: "French", address: "101 Paris Lane" }
  ];
  
  const menus = {
    "Sakura Sushi": [
      { name: "Salmon Roll", price: "$10" },
      { name: "Tuna Nigiri", price: "$8" },
      { name: "Eel Handroll", price: "$11" },
      { name: "Miso Soup", price: "$3" },
      { name: "Seaweed Salad", price: "$4" }
    ],
    "Bella Italia": [
      { name: "Spaghetti Carbonara", price: "$12" },
      { name: "Margherita Pizza", price: "$11" },
      { name: "Tiramisu", price: "$6" },
      { name: "Focaccia", price: "$5" },
      { name: "Minestrone Soup", price: "$7" }
    ],
    "Spice Route": [
      { name: "Butter Chicken", price: "$13" },
      { name: "Garlic Naan", price: "$3" },
      { name: "Paneer Tikka", price: "$9" },
      { name: "Biryani", price: "$12" },
      { name: "Mango Lassi", price: "$4" }
    ],
    "Tacos El Mexicano": [
      { name: "Beef Taco", price: "$4" },
      { name: "Quesadilla", price: "$6" },
      { name: "Nachos", price: "$7" },
      { name: "Guacamole", price: "$5" },
      { name: "Churros", price: "$4" }
    ],
    "Burger House": [
      { name: "Cheeseburger", price: "$7" },
      { name: "Fries", price: "$3" },
      { name: "Onion Rings", price: "$4" },
      { name: "Milkshake", price: "$5" },
      { name: "Chicken Burger", price: "$8" }
    ],
    "Green Garden": [
      { name: "Vegan Bowl", price: "$9" },
      { name: "Grilled Tofu", price: "$8" },
      { name: "Lentil Soup", price: "$6" },
      { name: "Stuffed Peppers", price: "$7" },
      { name: "Fruit Salad", price: "$5" }
    ],
    "Dragon Wok": [
      { name: "Kung Pao Chicken", price: "$10" },
      { name: "Fried Rice", price: "$6" },
      { name: "Spring Rolls", price: "$4" },
      { name: "Sweet & Sour Pork", price: "$11" },
      { name: "Hot & Sour Soup", price: "$5" }
    ],
    "Le Gourmet": [
      { name: "Duck Confit", price: "$18" },
      { name: "Crème brûlée", price: "$7" },
      { name: "Ratatouille", price: "$12" },
      { name: "French Onion Soup", price: "$8" },
      { name: "Escargot", price: "$14" }
    ]
  };
  
  let cart = [];
  
  function addToCart(item) {
    cart.push(item);
    updateCartDisplay();
  }
  
  function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartDisplay();
  }
  
  function updateCartDisplay() {
    const cartList = document.getElementById("cartItems");
    const cartTotal = document.getElementById("cartTotal");
  
    cartList.innerHTML = "";
    let total = 0;
  
    cart.forEach((item, index) => {
      const li = document.createElement("li");
      li.innerHTML = `
        ${item.name} – ${item.price}
        <button onclick="removeFromCart(${index})"
          style="margin-left:10px; background:#999; color:white; border:none; padding:2px 6px; border-radius:3px; cursor:pointer;">
          Remove
        </button>
      `;
      cartList.appendChild(li);
      total += parseFloat(item.price.replace("$", ""));
    });
  
    cartTotal.textContent = "$" + total.toFixed(2);
  }
  
  function checkout() {
    if (cart.length === 0) {
      alert("Your cart is empty!");
      return;
    }
  
    alert("Thank you for your order! 🛍️");
    cart = [];
    updateCartDisplay();
  }
  
  function showMenu(restaurantName) {
    const menu = menus[restaurantName] || [];
    const modal = document.getElementById("menuModal");
    const title = document.getElementById("menuTitle");
    const list = document.getElementById("menuItems");
  
    title.textContent = restaurantName + " Menu";
    list.innerHTML = "";
  
    menu.forEach(item => {
      const li = document.createElement("li");
      li.innerHTML = `
        ${item.name} – ${item.price}
        <button style="margin-left: 10px; background:#e24040; color:white; border:none; border-radius:4px; padding:2px 6px; cursor:pointer;"
          onclick='addToCart(${JSON.stringify(item)})'>Add</button>
      `;
      list.appendChild(li);
    });
  
    modal.style.display = "block";
  }
  
  function closeModal() {
    document.getElementById("menuModal").style.display = "none";
  }
  
  // Load cards and setup search
  window.addEventListener("DOMContentLoaded", () => {
    const list = document.getElementById("restaurantList");
  
    restaurants.forEach((restaurant) => {
      const card = document.createElement("div");
      card.className = "restaurant-card";
      card.innerHTML = `
        <h3>${restaurant.name}</h3>
        <p><strong>Cuisine:</strong> ${restaurant.cuisine}</p>
        <p><strong>Address:</strong> ${restaurant.address}</p>
        <button class="view-button" onclick="showMenu('${restaurant.name}')">View Menu</button>
      `;
      list.appendChild(card);
    });
  
    const searchInput = document.getElementById("searchInput");
    searchInput.addEventListener("input", () => {
      const query = searchInput.value.toLowerCase();
      const cards = document.querySelectorAll(".restaurant-card");
  
      cards.forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(query) ? "block" : "none";
      });
    });
  });
  